let handler = async m =>
  m.reply(
    `𝙷𝙾𝙻𝙰 𝚈𝙾𝚄 𝙽𝙴𝙴𝙳 𝙷𝙴𝙻𝙿 𝙾𝙽 𝚂𝙾𝙼𝙴 𝙾𝙵 𝚃𝙷𝙴 𝙰𝙱𝙾𝚅𝙴 𝚃𝙷𝙴𝙽 𝙵𝙾𝙻𝙻𝙾𝚆 𝚃𝙷𝙸𝚂 𝙸𝙽𝚂𝚃𝚁𝙰𝙲𝚃𝙸𝙾𝙽𝚂

    _______________________
    𝑓𝑜𝑙𝑙𝑜𝑤 𝑡ℎ𝑖𝑠 𝑠𝑡𝑒𝑝𝑠 𝑡𝑜 𝑐𝑜𝑛𝑡𝑎𝑐𝑡 𝑢𝑠 

  1. 𝐣𝐨𝐢𝐧 𝐭𝐡𝐢𝐬 𝐜𝐡𝐚𝐧𝐧𝐞𝐥 𝐥𝐢𝐧𝐤 𝐟𝐢𝐫𝐬𝐭 𝐚𝐟𝐭𝐞𝐫 𝐣𝐨𝐢𝐧𝐢𝐧𝐠 𝐦𝐲 𝐨𝐰𝐧𝐞𝐫 𝐰𝐢𝐥𝐥 𝐚𝐧𝐬𝐰𝐞𝐫 𝐲𝐨
  > *https://whatsapp.com/channel/0029VagJIAr3bbVBCpEkAM07*

  __________________________

  2. 𝐢𝐟 𝐭𝐡𝐢𝐬 𝐢𝐬 𝐧𝐨𝐭 𝐭𝐡𝐞 𝐫𝐞𝐚𝐥 𝐨𝐰𝐧𝐞𝐫 𝐩𝐥𝐞𝐚𝐬𝐞 𝐜𝐨𝐧𝐭𝐚𝐜𝐭 𝐭𝐡𝐞 𝐝𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 𝐟𝐨𝐫 𝐡𝐞𝐥𝐩
  > *923444844060* *© GlobalTechInfo*
  __________________________


`.trim()
  )
handler.help = ['ruth']
handler.tags = ['main']
handler.command = ['mrcs']

export default handler
