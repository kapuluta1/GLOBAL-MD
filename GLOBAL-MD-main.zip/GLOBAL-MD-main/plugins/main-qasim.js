let handler = async m =>
  m.reply(
    `

≡ © GlobalTechInfo Groups

─────────────
▢ Join WhatsApp Channel For Updates
https://whatsapp.com/channel/0029VagJIAr3bbVBCpEkAM07

▢ Group 2
https://t.me/GlobalBotInc

─────────────
≡ Disabled links? Chat Directly! 

▢ Group WhatsApp 
 https://GlobalTechInc
─────────────
▢ *Owner instagram*
 https://instagram.com/global.techinfo

▢ *YouTube*
• https://www.youtube.com/@GlobalTechInfo


`.trim()
  )
handler.help = ['ruth']
handler.tags = ['main']
handler.command = ['groups', 'channels', 'telegram', 'sgp', 'grp']

export default handler
